# Understanding RABBITX report counts

## What each number means

- **Recorded observations**: stored rule/response observations (`1 + relatedEvidence.size()` per original finding record). A repeated probe plan sharing one actual HTTP response is not an extra observation. Several cookies failing the same rule in one response remain one rule/response observation, with the cookie names retained in its evidence text.
- **Raw finding records**: the existing `findings` array length, usually one rule per requested URL. `findingCount` retains this meaning for existing integrations.
- **Rule groups**: records sharing rule ID, category, assessment status, severity and confidence. Groups reduce repeated presentation; they do not establish a shared root cause or a unique exploitable vulnerability. Different certainty levels are never combined.
- **Affected response URLs**: final response URLs for the recorded evidence, falling back to requested URL for legacy data. Redirecting aliases and actual hop URLs remain available in the original evidence and catalog.
- **Candidate groups**: configuration observations requiring human impact review, such as cookie attributes or contradictory CORS settings. Observation confidence is not confidence of exploitability.
- **Endpoint risk candidates**: endpoints having risk hints. **Parameter risk candidates** count endpoint/parameter/risk-type signals. IDOR, SQLi and XSS signals are name-based hypotheses; these are separate from configuration issue groups and confirmed vulnerabilities.
- **Confirmed groups**: require confirmed findings as input. The current automated checks and Mock do not create confirmed vulnerabilities.

Local demo expectations:

| Demo | Requests | Endpoints | Raw observations/records | Rule groups | Confirmed |
| --- | ---: | ---: | ---: | ---: | ---: |
| Case 1 | 5 | 4 | 20 | 4 | 0 |
| Case 2 | 4 | 3 | 32 | 8 | 0 |
| Case 3 | 3 | 2 | 0 | 0 | 0 |

Zero configured findings does not prove an application is secure. Wildcard CORS with credentials is a configuration conflict; browsers reject that combination, so it is not by itself proof of cross-origin data theft.

## JSON schema 1.5

All original keys and finding records remain. New top-level fields:

- `findingSummary`: `rawFindingCount`, `observationCount`, `groupedIssueCount`, `informationalIssueCount`, `candidateIssueCount`, `confirmedIssueCount`, `riskCandidateEndpointCount`, `parameterRiskCandidateCount`.
- `findingGroups`: each group has `ruleId`, `status`, `observationCount`, zero-based `findingIndexes` into the unchanged `findings` array, `affectedUrls`, and `evidenceIds` resolving to `evidenceCatalog`.

Reports still redact sensitive URL values and response secrets. With `--exclude-evidence`, group references and catalog IDs remain, but details are intentionally omitted. Different valid response snapshots are retained; aggregation never removes the original records.

Project schema remains version 4; versions 1–4 remain loadable. Saved report JSON is immutable on replay: old reports retain their original schema/data, and their HTML fallback remains readable. Resume generates a new schema 1.5 report without rewriting prior runs or project defaults.

## Local QA reproduction

Run from the repository root in Windows PowerShell 7 after building Release:

```powershell
pwsh -File .\tools\test-client.ps1 -Configuration Release
pwsh -File .\tools\test-product-qa.ps1 `
  -Executable .\x64\Release\RABBITX.exe `
  -OutputDirectory .\dist\qa-new-run -Port 0
```

Use a fresh output directory. Port 0 selects an unused loopback port; the runner starts/stops only its own fixture and leaves an existing server on 8787 alone. One logged local warm-up request initializes the PowerShell fixture before measuring request arrival gaps. Per-case counts exclude this warm-up. Server arrival measurements allow 20ms scheduling/observation tolerance at a 150ms setting; the native suite separately checks the sender's monotonic limiter.

The QA output contains actual request logs, JSON/HTML reports, saved projects and `qa-results.json`. It does not contact external security targets, model APIs or commercial services.
