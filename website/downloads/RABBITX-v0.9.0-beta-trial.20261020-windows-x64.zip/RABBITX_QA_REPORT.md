# RABBITX v0.9.0-beta 产品验收报告

验收日期：2026-10-19（Asia/Shanghai）。平台：Windows x64、Visual Studio 2022 / MSBuild 17.14、MSVC 14.44、PowerShell 7；演示服务使用 Windows PowerShell。本轮未使用 WSL、E 盘、新付费依赖、模型 API 或云服务。

## 1. 交付结论

**受控免费试用：可以开始。标准 US$24/月 Pro 订阅销售：暂缓。**

本轮证明了当前客户端在合成的本地目标上能够稳定执行受控 GET、识别预设端点/规则、保存可追溯证据并导出可阅读报告。修复后的报告可以区分规则组、原始观察和名称启发式风险候选；未发生影响正常使用的崩溃，最终回归无失败。

尚不足以证明真实业务漏洞检出能力、生产授权/支付链路或持续付费价值。Mock 不是语言模型；当前没有已交付、可明确区别于既有 Free 功能的付费分析能力。不能把订阅授权诊断接口、20/32 条观察或 Mock 解释宣传成已验证漏洞或真实 AI Pro 服务。本结论不否定后续付费验证，但不建议以现有证据直接面向陌生用户销售成熟 Pro 产品。

## 2. 基线、回滚和隔离

- 源码基线：`c6392703dfc0bf3546d961d7890eca223a2821cb`。
- 验收分支：`codex/v0.9-product-qa`；源码修复独立提交，可回到基线比较/回滚。
- 原包：`dist/RABBITX-v0.9.0-beta-windows-x64.zip`，始终未覆盖。
- 原包 SHA-256（修复前后相同）：`adc1bd5bedd92a09b6a8f00961876f602bee0430e77df97bcde04e8fde89955c`。
- 测试包：`dist/RABBITX-v0.9.0-beta-qa.20261019-windows-x64.zip` 及 `.sha256`；这是 QA 制品名称，程序仍显示 `RABBITX v0.9.0-beta`，没有创建正式 Release。
- 原包解压副本、失败过程记录及完整运行证据保留在 `dist/qa-20261019/`。原始商业 backend/ 和授权文档未提交改动均保留，未纳入本轮客户端提交；未修改 Paddle、Worker、生产 D1 或部署配置。

## 3. 已修复问题及修改前后

### P0：无损报告聚合和计数

修改前：`findings` 以规则/URL 保存，HTML 默认逐条展示。Case 2 的 32 个记录很容易被理解为 32 个漏洞。

修改后：

1. 保留全部原始 `findings`、`findingCount`、证据快照和目录 ID。
2. JSON schema 升为 **1.5**，只新增 `findingSummary`、`findingGroups`，不改变旧字段类型和含义。若外部消费者硬编码只允许版本 1.4，需要更新其版本判断。
3. 按规则 ID、类别、状态、严重度和观察置信度建立展示组；不混合不同确定性，也不宣称这些组代表独立根因或已证实漏洞。
4. 每组保存原始记录下标、所有受影响最终响应 URL、证据 ID 和观察数。重定向别名仍在原始证据中；同一响应多个 Cookie 的同类规则保持一个响应级观察，Cookie 名称保留在证据说明中。
5. HTML 优先展示摘要和规则组；原始证据和 Mock 建议可展开，点击证据引用会展开目录。全部记录仍在 JSON 和页面数据内。
6. 将端点分数描述为“复核优先级”；将 IDOR/SQLi/XSS 等名称推断与配置观察分开计数。Case 3 可以有端点/参数复核候选，同时配置发现仍为零。
7. CLI 按组输出，并明确总数不是已验证漏洞数。

旧 Project v1–v4 继续兼容。离线 Replay 不重写历史 JSON；旧报告沿用原始 schema，HTML 提供旧数据回退展示，旧报告不会被悄悄修改。Resume 生成新的 1.5 报告。

### P1：重定向可靠性

- 原实现先把每跳 `requestedUrl` 改成初始 URL，再捕获证据，导致中间跳的实际请求地址不准确。现在先保存真实 hop 快照，再设置整个操作的初始 URL。
- 重定向循环、跳数上限、无法解析的目标和异常结束现在返回结构化 `failed`，保留已完成的跳证据和停止原因。
- 网络统计仍按实际 HTTP 尝试/完成记录。比如成功收到若干 302 后因循环停止，操作失败不等于这些已收到的 HTTP 响应是网络失败。

### P2：交付和说明

- README 对齐本次 v0.9 QA 包、Mock 限制、现有 Free 功能和定价验证状态。
- 新增计数说明 `docs/REPORT_COUNTS.md`。
- 打包脚本默认拒绝覆盖已有同名包；需要独立 `-Version` 或显式 `-Force`。已实测原包保护生效。
- 测试包包含新说明、验收报告和本次生成的三个 JSON/HTML 示例；不再捆绑旧的试验定价宣传页。

## 4. 三个场景的实际重测

原包也在本轮实际运行，未沿用旧日志。原包基线检查 **34/34 通过**。最终 Release 的完整验收 **43/43 通过**。

| 场景 | 实际请求 | 端点 | 原始观察/记录 | 聚合规则组 | 信息性组 | 待复核配置组 | 确认漏洞组 | 失败请求 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Case 1 | 5 | 4/4 | 20 | 4 | 4 | 0 | 0 | 0 |
| Case 2 | 4 | 3/3 | 32 | 8 | 4 | 4 | 0 | 0 |
| Case 3 | 3 | 2/2 | 0 | 0 | 0 | 0 | 0 | 0 |

Case 1 核对了 users、search、graphql、oauth/token 四条确切路径。Case 2 逐一核对：CSP、nosniff、frame protection、Referrer-Policy、credentialed CORS wildcard、Cookie Secure/HttpOnly/SameSite 共八个规则 ID。CORS 通配符与 credentials 冲突并不是已证明的数据窃取；浏览器会拒绝该组合。

Case 1/2/3 的端点复核候选数分别为 4/3/2，参数风险类型信号数各为 3，均未计作确认漏洞。

服务端请求记录逐条核对 GET、路径边界和数量；所有实际目标请求均为自建 loopback 服务或故意关闭的 loopback 端口。原有测试里的 `outside.invalid` 仅用于 Scope 拒绝验证，没有发出该目标的请求。

## 5. 自动化测试证据

| 测试 | Debug | Release / 其他 |
| --- | ---: | ---: |
| 原生 AI/HTTP/Scope/预算/限速/Project/报告（含新增 10 项） | 93 通过 | 93 通过 |
| 原有 CLI/配置优先级/Project/Replay | 13 通过 | 13 通过 |
| 授权 CLI 共存与 Free 功能 | 13 通过 | 13 通过 |
| 原生授权（注入模拟传输与内存 token store） | — | 8 通过 |
| 最终 Release 三场景及边界验收 | — | 43 通过 |
| Edge 实际执行 HTML 页面断言 | — | 3 个报告通过 |
| 解压后的 QA 包内 EXE 三场景及边界验收 | — | 43 通过 |

Debug/Release 均编译成功，最终编译日志无编译器/链接器错误或警告。Git 的 LF/CRLF 提示不是编译警告。

覆盖内容包括：

- max=0/1/2 时服务端观察到的请求数量与预算一致；原有 redirect 每跳计费、Scope 拒绝不扣预算、预算耗尽不继续发送。
- 发送端单调时钟限速单测，以及实际服务端到达间隔。配置 150ms 时，最终三个场景最小观测间隔分别为 **142.7621 / 154.3587 / 160.2917ms**；到达时间允许 20ms 调度/测量偏差，不把服务端到达时间冒充精确发送时间。
- host/path 拒绝无网络发送；编码路径穿越、域名后缀混淆、跨域 redirect 拒绝；循环仅发送一次，跳数上限最多 11 次 HTTP 尝试。
- 连接拒绝、超时、截断响应、超过 8MiB 的响应、重复 Cookie、401 说明；失败响应不生成伪发现。
- 每个原始发现的证据 ID、URL、响应指纹与目录一致；组内每个 URL 的证据保留。
- JSON/HTML 导出、Project 保存、resume 新预算且不修改默认配置、离线 Replay 零请求且不修改项目；配置文件/CLI 覆盖、非法字段类型错误、旧 Project v1–v4。
- Mock label、无证据不臆造风险、schema/伪造 ID/不受支持动作/异常/超时/不可用；AI 不执行建议，不绕过 Scope/预算/方法约束。
- Edge 执行真实 HTML 中的 JavaScript，验证摘要数字、组卡片数、全部快照、Mock 标签及证据跳转；不只是检查 HTML 字符串存在。

### 证据路径

- `x64/qa-debug-final.log`、`x64/qa-release-final.log`。
- `x64/qa-integration-debug.log`、`x64/qa-integration-release.log`。
- `x64/qa-auth-native.log`、`x64/qa-release-dependencies.txt`。
- `x64/qa-before-pass.log`、`x64/qa-after-final.log`、`x64/qa-browser-final.log`。
- `dist/qa-20261019/before-pass/`：原包 JSON/HTML/Project/服务端请求记录与结果。
- `dist/qa-20261019/after-final/`：最终程序相同证据，以及 Edge 渲染后的 DOM。
- `examples/reports/qa-case-1/2/3.json` 和相应 `.html` 为最终示例。

最终 Release EXE SHA-256：`a4befa44e8f5c4983e896b5889422b280f0fceb04fa8af8182345ab70682f0de`。打包后应核对包内 `SHA256SUMS.txt`。

已实际解压并运行新包：包内 EXE 与最终 Release 的 SHA-256 完全一致，独立的 `dist/qa-20261019/packaged-run/` 再次完成 43 项验收，结果记录在 `x64/qa-packaged-run.log`。压缩包 SHA-256 以同名 `.sha256` 文件为准。

## 6. 过程失败和最终失败项

**最终回归失败项：0。** 以下过程问题均保留日志，没有隐藏或改作通过：

1. 默认 8787 已有服务占用：测试服务无法绑定；未终止原服务，改用 `-Port 0` 分配独立端口。
2. 新脚本把 PowerShell 7 自动转换的日期再经字符串解析，丢失亚秒精度，造成限速假失败：改为 `DateTimeOffset` 直接转换，并先预热 PowerShell fixture，保留完整请求日志；不放宽发送端单测。
3. 新脚本初始把连接拒绝的预期退出码写为 0；真实程序正确导出失败报告并返回 1。已修正测试预期，未把网络失败改成成功退出。

对应早期记录在 `dist/qa-20261019/before*` 和 `x64/qa-before*.log`；正式比较使用 `before-pass` 与 `after-final`。

## 7. 源码修改清单

| 文件 | 修改用途 |
| --- | --- |
| `Core/Models/finding.h`, `finding.cpp` | 纯派生展示组及无损证据引用 |
| `Report/json_reporter.cpp` | additive schema 1.5、计数和组索引 |
| `Report/html_reporter.cpp` | 分组、摘要、候选解释、折叠与证据链接 |
| `Interface/console_ui.cpp` | 终端组输出及计数含义 |
| `Infrastructure/Network/http_client.cpp` | hop 实际 URL 与 redirect 停止状态 |
| `tools/tests/client_tests.cpp`, `Start-TestServer.ps1` | 聚合、确定性、重定向和旧功能回归 |
| `tools/test-product-qa.ps1` | 原包/新包三场景、真实请求计数与边界验收 |
| `tools/test-html-report.ps1` | 本机 Edge 实际渲染断言，无浏览器下载 |
| `examples/Start-DemoServer.ps1` | 可选 ready 文件和实际请求时间记录 |
| `tools/package-windows.ps1` | 防覆盖、QA 文档和示例打包 |
| `README.md`, `docs/REPORT_COUNTS.md`, 本文件 | 版本、计数、交付能力和局限 |
| `examples/reports/qa-case-*` | 本轮真实生成的三个 JSON/HTML 示例 |

没有改架构目录、计费边界或检测规则数量。没有增加付费依赖。

## 8. 构建、复测与交付范围

```powershell
pwsh -File .\tools\test-client.ps1 -Configuration Debug -MSBuildPath 'D:\VS\MSBuild\Current\Bin\MSBuild.exe'
pwsh -File .\tools\test-client.ps1 -Configuration Release -MSBuildPath 'D:\VS\MSBuild\Current\Bin\MSBuild.exe'
pwsh -File .\tools\test-product-qa.ps1 -Executable .\x64\Release\RABBITX.exe -OutputDirectory .\dist\qa-another-run -Port 0
pwsh -File .\tools\test-html-report.ps1 -ReportDirectory .\dist\qa-another-run
pwsh -File .\tools\package-windows.ps1 -Version v0.9.0-beta-qa.20261019
```

复测使用新输出目录；已存在包默认拒绝覆盖。测试不需密钥或登录。Release EXE 仅依赖 Windows 自带 `KERNEL32.dll`、`ADVAPI32.dll`、`WINHTTP.dll`、`bcrypt.dll`，未动态依赖 MSVCP/VCRUNTIME。当前主机实际运行通过；未声称已在所有干净 Windows 10/11 主机矩阵验证。

未测试或未交付：真实 AI Provider、生产支付/邮件/授权验收、自动漏洞利用、复杂认证业务流、真实客户目标检出率、压力/长期运行、完整浏览器爬虫、正式付费 Pro 差异化功能。旧后台并行改动和 `authorization_mode=acceptance` 的生产语义不属于这次客户端 QA 的认证范围。

下一步优先让少量真实研究人员在授权目标上免费试用，记录节省的整理时间、误解/误报和愿意持续使用的理由，再决定是否有足够证据支持 US$24/月。不要为这一步增加付费基础设施或继续扩张检测功能。
